# Trench Crusade 3D RTS — Ashen Crossing · Faz 04

Mobil öncelikli, tarayıcıda çalışan, harici görsel/model/ses kullanmayan WebGL 2 RTS prototipi. Faz 04, Faz 03’ün native ES Module mimarisini korur; New Antioch’a aktif lojistik, üç kaynaklı ekonomi, muharebe mühendisleri, gerçek şantiye akışı, üretim kuyruğu, kuvvet kapasitesi ve tamir sistemi ekler. Black Grail bu fazda eski ekonomi ve organik inşa davranışıyla çalışmaya devam eder.

Modüler klasör kaynak sürümüdür. `Trench-Crusade-Faz04.html` yalnızca kolay dağıtım ve otomatik entegrasyon testi için üretilen bağımsız kopyadır.

## Çalıştırma

Kurulum veya bundler zorunlu değildir. ES Module güvenlik kuralları nedeniyle modüler sürümü `file://` yerine basit bir HTTP sunucusuyla açın:

```bash
python3 -m http.server 8080
```

Ardından `http://localhost:8080/` adresini açın. Aynı işlem için `npm run serve` kullanılabilir. Bağımsız `Trench-Crusade-Faz04.html` doğrudan açılabilir.

## Kontroller ve Faz 04 akışı

- Dokun: birlik/yapı seç; zemine dokunarak hareket et; düşmana dokunarak saldır.
- Alan seçimi: araç çubuğundan alan moduna geçip sürükle.
- Kamera: sürükle; iki parmak veya tekerlek ile yakınlaştır.
- Kaynak: mühendis seçip ikmal, enkaz veya insan gücü noktasına dokun. Ekip yükü HQ/depo alanına taşır ve teslim eder.
- Otomatik toplama: mühendis seçiliyken `Oto topla`; ekip atanan kaynak türünde yakın hedefi aralıklı arar.
- İnşa: mühendis seç → `Üs inşa et` → yapı → zemin → onay. Mühendis şantiyeye ulaşmadan ilerleme başlamaz.
- Yardım/tamir: seçili mühendisle dost şantiyeye veya hasarlı tamamlanmış yapıya dokun.
- Üretim: Kışla piyade/ağır piyade; Mühendislik Atölyesi muharebe mühendisi üretir.

## Proje yapısı

```text
index.html                     UI kökleri ve module entry
style.css                      Mobil öncelikli grimdark arayüz
src/main.js                    İki satırlık başlangıç noktası
src/core/                      Game composition, state, config, time, RNG
src/simulation/                Sabit tick simulation ve capture
src/economy/                   Faction economy strategy/registry
src/world/                     Terrain, harita ve resource node yöneticisi
src/units/                     Squad, hareket, lojistik ve mühendislik
src/combat/                    Hedef, hasar, ölüm ve projectile sınırı
src/buildings/                 Building, footprint, construction ve production
src/factions/                  Faction registry ve faction hook’ları
src/effects/                   VisualEvents ve havuzlanmış efekt sistemleri
src/render/                    WebGL, kamera, LOD ve prosedürel art
src/input/                     Touch, selection, JSON command ve dispatcher
src/ui/                        HUD, minimap, build menu ve performans paneli
src/ai/                        Render’dan bağımsız AI
src/audio/                     Kodla üretilen Web Audio
data/                          Unit, building, faction, resource ve balance verisi
tests/                         Architecture, simulation, economy, effects, integration
```

Simulation, render state’e yazmaz. Combat ve mühendislik sonuçları tek yönlü `VisualEvents` üretir. Input akışı `TouchControls → SelectionSystem → CommandSystem → Simulation` şeklindedir. Ekonomi, toplama, inşa, üretim ve tamir sabit simulation tick’inde ilerler; gameplay hot path’inde `Math.random` veya `Date.now` kullanılmaz.

## Veri ekleme

### Yeni unit

1. `data/units.js` içine kimlik, faction adları, combat değerleri, `squadSize`, `costs`, `forceCost`, `producer`, `requires` ve `time` ekleyin.
2. `data/factions.js` içindeki ilgili `allowedUnits` listesine kimliği ekleyin.
3. Gerekirse silueti `src/render/art/SoldierArt.js` veya faction visual strategy içinde tanımlayın.
4. Üretim, cap, save ve command regresyon testi ekleyin.

### Yeni building

1. `data/buildings.js` içine `costs`, `time`, `hp`, `footprint`, `requires`, `production`, storage/force hook’larını ekleyin.
2. İlgili faction’ın `allowedBuildings` listesine ekleyin.
3. Genel davranışı `src/buildings/`; faction davranışını strategy/hook katmanında uygulayın.
4. Prosedürel siluet, placement, construction ve destruction testlerini ekleyin.

### Yeni faction veya ekonomi

1. `data/factions.js` içinde izin listeleri, başlangıç ordusu ve `systems.economy` anahtarı oluşturun.
2. `FactionEconomyStrategy` tabanından strateji üretip `EconomyRegistry`ye kaydedin.
3. Faction’a özel render strategy ve gerekiyorsa construction hook’u ekleyin.
4. Core içine faction kimliği dalları yaymak yerine strategy özelliklerini kullanın.

### Yeni resource node

`data/resources.js` içinde kaynak tanımı ve deterministik harita yerleşimi ekleyin. Toplama yükü, süre ve görsel renk burada; teslim ve kapasite kuralları ekonomi strategy’sindedir.

## Test ve build

```bash
npm test
npm run build
```

`npm install` gerekmez. Test paketi toplam **67 otomatik test** çalıştırır: önceki mimari/savaş/efekt regresyonları, 160 asker, resource node, gather-return-delivery, depletion, auto gather, engineer construction, diminishing returns, prerequisite, queue, force cap, repair, save/load, version migration, command serialization, determinism ve Black Grail regresyonu.

`npm run build`, 74 modüllük kaynak ağından `Trench-Crusade-Faz04.html` üretir. Build aracı yalnızca Python standart kütüphanesini kullanır.

## GitHub Pages

Repository kökünü Pages kaynağı olarak yayınlayın. Import ve asset yollarının tümü relatiftir; absolute filesystem path yoktur. Proje alt dizin altında ek bir build adımı olmadan çalışır.

Ayrıntılı sonuçlar: `FAZ-04-RAPOR.md`.
